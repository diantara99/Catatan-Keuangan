import { useState } from "react";

const formatRupiah = (angka) =>
  new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(angka);

const formatTanggal = (dateStr) =>
  new Date(dateStr).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });

const DUMMY_USER = { email: "demo@umkm.com", password: "demo123", nama: "Budi Santoso", usaha: "Warung Makan Barokah" };

const DUMMY_TRANSAKSI = [
  { id: 1, jenis: "pemasukan", kategori: "Penjualan", keterangan: "Penjualan nasi bungkus", jumlah: 450000, tanggal: "2026-06-05" },
  { id: 2, jenis: "pengeluaran", kategori: "Bahan Baku", keterangan: "Beli beras & sayur", jumlah: 180000, tanggal: "2026-06-05" },
  { id: 3, jenis: "pemasukan", kategori: "Penjualan", keterangan: "Penjualan minuman", jumlah: 120000, tanggal: "2026-06-04" },
  { id: 4, jenis: "pengeluaran", kategori: "Operasional", keterangan: "Bayar listrik", jumlah: 75000, tanggal: "2026-06-04" },
  { id: 5, jenis: "pemasukan", kategori: "Lainnya", keterangan: "Pesanan katering", jumlah: 800000, tanggal: "2026-06-03" },
  { id: 6, jenis: "pengeluaran", kategori: "Bahan Baku", keterangan: "Beli minyak goreng", jumlah: 95000, tanggal: "2026-06-03" },
];

const KATEGORI = {
  pemasukan: ["Penjualan", "Jasa", "Investasi", "Lainnya"],
  pengeluaran: ["Bahan Baku", "Gaji", "Operasional", "Sewa", "Listrik & Air", "Lainnya"],
};

// ─── INPUT STYLE ────────────────────────────────────────────────
const inputStyle = {
  width: "100%", padding: "11px 14px", borderRadius: 10,
  border: "1px solid rgba(255,255,255,0.15)",
  background: "#0d1117", color: "#fff", fontSize: 14, boxSizing: "border-box", outline: "none",
};

// ─── LOGIN ──────────────────────────────────────────────────────
function LoginPage({ onLogin }) {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showReg, setShowReg] = useState(false);
  const [reg, setReg] = useState({ nama: "", usaha: "", email: "", password: "" });
  const [regMsg, setRegMsg] = useState("");

  const handleLogin = () => {
    setError(""); setLoading(true);
    setTimeout(() => {
      if (form.email === DUMMY_USER.email && form.password === DUMMY_USER.password) {
        onLogin(DUMMY_USER);
      } else setError("Email atau password salah. Coba: demo@umkm.com / demo123");
      setLoading(false);
    }, 800);
  };

  const handleReg = () => {
    if (!reg.nama || !reg.usaha || !reg.email || !reg.password) { setRegMsg("Semua kolom wajib diisi!"); return; }
    setRegMsg("✅ Pendaftaran berhasil! Silakan login.\n(Demo: gunakan demo@umkm.com / demo123)");
    setTimeout(() => { setShowReg(false); setRegMsg(""); }, 3000);
  };

  return (
    <div style={{
      minHeight: "100vh", background: "linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%)",
      display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Segoe UI', sans-serif", padding: 20
    }}>
      <div style={{ width: "100%", maxWidth: 420 }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{
            width: 64, height: 64, borderRadius: 18, background: "linear-gradient(135deg,#f7971e,#ffd200)",
            display: "flex", alignItems: "center", justifyContent: "center", fontSize: 30, margin: "0 auto 14px",
            boxShadow: "0 8px 32px rgba(247,151,30,0.4)"
          }}>💰</div>
          <h1 style={{ color: "#fff", fontSize: 26, fontWeight: 800, margin: 0 }}>CatatUMKM</h1>
          <p style={{ color: "#94a3b8", fontSize: 14, margin: "6px 0 0" }}>Pencatatan Keuangan Usaha Anda</p>
        </div>

        <div style={{
          background: "rgba(255,255,255,0.05)", backdropFilter: "blur(20px)",
          border: "1px solid rgba(255,255,255,0.12)", borderRadius: 20, padding: 32,
          boxShadow: "0 25px 60px rgba(0,0,0,0.4)"
        }}>
          {!showReg ? (
            <>
              <h2 style={{ color: "#fff", fontSize: 20, fontWeight: 700, margin: "0 0 24px" }}>Masuk ke Akun</h2>
              {["email", "password"].map(f => (
                <div key={f} style={{ marginBottom: 16 }}>
                  <label style={{ color: "#94a3b8", fontSize: 13, fontWeight: 600, display: "block", marginBottom: 8, textTransform: "uppercase" }}>
                    {f === "email" ? "Email" : "Password"}
                  </label>
                  <input type={f === "password" ? "password" : "text"} value={form[f]}
                    onChange={e => setForm({ ...form, [f]: e.target.value })}
                    onKeyDown={e => e.key === "Enter" && handleLogin()}
                    placeholder={f === "email" ? "email@usaha.com" : "••••••••"}
                    style={inputStyle} />
                </div>
              ))}
              {error && <div style={{ background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.3)", borderRadius: 8, padding: "10px 14px", color: "#fca5a5", fontSize: 13, marginBottom: 16 }}>{error}</div>}
              <button onClick={handleLogin} disabled={loading} style={{
                width: "100%", padding: 14, borderRadius: 10, border: "none",
                background: loading ? "#64748b" : "linear-gradient(135deg,#f7971e,#ffd200)",
                color: loading ? "#94a3b8" : "#1a1a1a", fontWeight: 700, fontSize: 16, cursor: loading ? "not-allowed" : "pointer"
              }}>{loading ? "Memverifikasi..." : "Masuk"}</button>
              <div style={{ textAlign: "center", marginTop: 20 }}>
                <span style={{ color: "#64748b", fontSize: 14 }}>Belum punya akun? </span>
                <span onClick={() => setShowReg(true)} style={{ color: "#ffd200", fontSize: 14, fontWeight: 600, cursor: "pointer" }}>Daftar Gratis</span>
              </div>
              <div style={{ marginTop: 16, padding: "12px 14px", background: "rgba(255,210,0,0.08)", borderRadius: 8, border: "1px solid rgba(255,210,0,0.2)", textAlign: "center" }}>
                <p style={{ color: "#fbbf24", fontSize: 12, margin: 0 }}>🔑 Demo: <strong>demo@umkm.com</strong> / <strong>demo123</strong></p>
              </div>
            </>
          ) : (
            <>
              <h2 style={{ color: "#fff", fontSize: 20, fontWeight: 700, margin: "0 0 24px" }}>Daftar Akun Baru</h2>
              {[["nama", "Nama Pemilik", "Nama lengkap Anda"], ["usaha", "Nama Usaha", "Nama toko/usaha Anda"], ["email", "Email", "email@usaha.com"], ["password", "Password", "Min. 6 karakter"]].map(([f, label, ph]) => (
                <div key={f} style={{ marginBottom: 14 }}>
                  <label style={{ color: "#94a3b8", fontSize: 13, fontWeight: 600, display: "block", marginBottom: 8, textTransform: "uppercase" }}>{label}</label>
                  <input type={f === "password" ? "password" : "text"} value={reg[f]}
                    onChange={e => setReg({ ...reg, [f]: e.target.value })} placeholder={ph} style={inputStyle} />
                </div>
              ))}
              {regMsg && <div style={{ background: "rgba(34,197,94,0.15)", border: "1px solid rgba(34,197,94,0.3)", borderRadius: 8, padding: "10px 14px", color: "#86efac", fontSize: 13, marginBottom: 14, whiteSpace: "pre-line" }}>{regMsg}</div>}
              <button onClick={handleReg} style={{
                width: "100%", padding: 13, borderRadius: 10, border: "none",
                background: "linear-gradient(135deg,#22c55e,#16a34a)", color: "#fff", fontWeight: 700, fontSize: 15, cursor: "pointer"
              }}>Daftar Sekarang</button>
              <div style={{ textAlign: "center", marginTop: 16 }}>
                <span onClick={() => setShowReg(false)} style={{ color: "#ffd200", fontSize: 14, fontWeight: 600, cursor: "pointer" }}>← Kembali ke Login</span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── APP ─────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(null);
  const [transaksi, setTransaksi] = useState(DUMMY_TRANSAKSI);
  const [menu, setMenu] = useState("dashboard");
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState("semua");
  const [form, setForm] = useState({ jenis: "pemasukan", kategori: "Penjualan", keterangan: "", jumlah: "", tanggal: new Date().toISOString().split("T")[0] });
  const [formError, setFormError] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (!user) return <LoginPage onLogin={setUser} />;

  const totalMasuk = transaksi.filter(t => t.jenis === "pemasukan").reduce((s, t) => s + t.jumlah, 0);
  const totalKeluar = transaksi.filter(t => t.jenis === "pengeluaran").reduce((s, t) => s + t.jumlah, 0);
  const saldo = totalMasuk - totalKeluar;
  const filtered = filter === "semua" ? transaksi : transaksi.filter(t => t.jenis === filter);

  const tambah = () => {
    if (!form.keterangan || !form.jumlah) { setFormError("Keterangan dan jumlah wajib diisi!"); return; }
    setTransaksi([{ id: Date.now(), ...form, jumlah: parseInt(String(form.jumlah).replace(/\D/g, "")) }, ...transaksi]);
    setForm({ jenis: "pemasukan", kategori: "Penjualan", keterangan: "", jumlah: "", tanggal: new Date().toISOString().split("T")[0] });
    setShowForm(false); setFormError("");
    setSuccessMsg("✅ Transaksi berhasil dicatat!");
    setTimeout(() => setSuccessMsg(""), 3000);
  };

  const hapus = (id) => setTransaksi(transaksi.filter(t => t.id !== id));

  const menuItems = [
    { id: "dashboard", icon: "📊", label: "Dashboard" },
    { id: "transaksi", icon: "📋", label: "Transaksi" },
    { id: "laporan", icon: "📈", label: "Laporan" },
    { id: "profil", icon: "👤", label: "Profil" },
  ];

  const StatCard = ({ label, value, icon, color }) => (
    <div style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 16, padding: "18px 16px", flex: 1, minWidth: 0 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <span style={{ fontSize: 20 }}>{icon}</span>
        <span style={{ color: "#94a3b8", fontSize: 12, fontWeight: 600 }}>{label}</span>
      </div>
      <div style={{ color, fontSize: 18, fontWeight: 800, wordBreak: "break-all" }}>{formatRupiah(value)}</div>
    </div>
  );

  const TxRow = ({ t }) => (
    <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: "13px 14px", marginBottom: 8, display: "flex", alignItems: "center", gap: 10 }}>
      <div style={{ width: 38, height: 38, borderRadius: 10, flexShrink: 0, background: t.jenis === "pemasukan" ? "rgba(52,211,153,0.15)" : "rgba(248,113,113,0.15)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>
        {t.jenis === "pemasukan" ? "📥" : "📤"}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ color: "#e2e8f0", fontSize: 14, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.keterangan}</div>
        <div style={{ color: "#475569", fontSize: 12 }}>{t.kategori} • {formatTanggal(t.tanggal)}</div>
      </div>
      <div style={{ textAlign: "right", flexShrink: 0 }}>
        <div style={{ color: t.jenis === "pemasukan" ? "#34d399" : "#f87171", fontWeight: 800, fontSize: 14 }}>
          {t.jenis === "pemasukan" ? "+" : "-"}{formatRupiah(t.jumlah)}
        </div>
        <div onClick={() => hapus(t.id)} style={{ color: "#ef4444", fontSize: 11, cursor: "pointer", marginTop: 4 }}>🗑 Hapus</div>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: "#0d1117", fontFamily: "'Segoe UI', sans-serif" }}>
      {/* Overlay */}
      {sidebarOpen && <div onClick={() => setSidebarOpen(false)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", zIndex: 40 }} />}

      {/* Sidebar */}
      <div style={{
        width: 220, background: "#111827", borderRight: "1px solid rgba(255,255,255,0.06)",
        display: "flex", flexDirection: "column", padding: "24px 0",
        position: "fixed", top: 0, bottom: 0, left: sidebarOpen ? 0 : -220, zIndex: 50, transition: "left 0.3s ease"
      }}>
        <div style={{ padding: "0 20px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 38, height: 38, borderRadius: 10, background: "linear-gradient(135deg,#f7971e,#ffd200)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>💰</div>
            <div>
              <div style={{ color: "#fff", fontWeight: 800, fontSize: 15 }}>CatatUMKM</div>
              <div style={{ color: "#475569", fontSize: 11 }}>v1.0</div>
            </div>
          </div>
        </div>
        <div style={{ padding: "14px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          <div style={{ color: "#fff", fontWeight: 700, fontSize: 14 }}>{user.nama}</div>
          <div style={{ color: "#64748b", fontSize: 12, marginTop: 2 }}>{user.usaha}</div>
        </div>
        <nav style={{ flex: 1, padding: "12px 10px" }}>
          {menuItems.map(m => (
            <div key={m.id} onClick={() => { setMenu(m.id); setSidebarOpen(false); }} style={{
              display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 10, cursor: "pointer", marginBottom: 4,
              background: menu === m.id ? "rgba(247,151,30,0.15)" : "transparent",
              borderLeft: menu === m.id ? "3px solid #f7971e" : "3px solid transparent",
              color: menu === m.id ? "#ffd200" : "#64748b", fontWeight: menu === m.id ? 700 : 500, fontSize: 14
            }}>
              <span style={{ fontSize: 18 }}>{m.icon}</span>{m.label}
            </div>
          ))}
        </nav>
        <div style={{ padding: "12px 10px", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
          <div onClick={() => setUser(null)} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 10, cursor: "pointer", color: "#ef4444", fontSize: 14, fontWeight: 600 }}>
            🚪 Keluar
          </div>
        </div>
      </div>

      {/* Top Bar */}
      <div style={{ background: "#111827", borderBottom: "1px solid rgba(255,255,255,0.06)", padding: "14px 20px", display: "flex", alignItems: "center", gap: 14, position: "sticky", top: 0, zIndex: 30 }}>
        <button onClick={() => setSidebarOpen(!sidebarOpen)} style={{ background: "rgba(255,255,255,0.08)", border: "none", borderRadius: 8, color: "#fff", fontSize: 18, padding: "6px 10px", cursor: "pointer" }}>☰</button>
        <h1 style={{ color: "#fff", fontSize: 18, fontWeight: 800, margin: 0, flex: 1 }}>
          {menuItems.find(m => m.id === menu)?.icon} {menuItems.find(m => m.id === menu)?.label}
        </h1>
        <button onClick={() => setShowForm(true)} style={{
          background: "linear-gradient(135deg,#f7971e,#ffd200)", border: "none", borderRadius: 10,
          color: "#1a1a1a", fontWeight: 700, fontSize: 13, padding: "9px 16px", cursor: "pointer"
        }}>+ Catat</button>
      </div>

      {/* Content */}
      <div style={{ padding: 20, maxWidth: 600, margin: "0 auto" }}>
        {successMsg && <div style={{ background: "rgba(34,197,94,0.15)", border: "1px solid rgba(34,197,94,0.3)", borderRadius: 10, padding: "12px 16px", color: "#86efac", fontSize: 14, marginBottom: 20, fontWeight: 600 }}>{successMsg}</div>}

        {/* DASHBOARD */}
        {menu === "dashboard" && (
          <>
            <div style={{ marginBottom: 20 }}>
              <h2 style={{ color: "#fff", fontSize: 16, fontWeight: 700, margin: "0 0 4px" }}>Selamat datang, {user.nama.split(" ")[0]}! 👋</h2>
              <p style={{ color: "#64748b", fontSize: 13, margin: 0 }}>Ringkasan keuangan {user.usaha}</p>
            </div>
            <div style={{ background: "linear-gradient(135deg,#1e3a5f,#1a2f4a)", border: "1px solid rgba(247,151,30,0.3)", borderRadius: 18, padding: 24, marginBottom: 16, textAlign: "center" }}>
              <div style={{ color: "#94a3b8", fontSize: 13, fontWeight: 600, marginBottom: 8 }}>TOTAL SALDO</div>
              <div style={{ color: saldo >= 0 ? "#34d399" : "#f87171", fontSize: 32, fontWeight: 900 }}>{formatRupiah(saldo)}</div>
              <div style={{ color: "#475569", fontSize: 12, marginTop: 6 }}>{transaksi.length} transaksi tercatat</div>
            </div>
            <div style={{ display: "flex", gap: 12, marginBottom: 24 }}>
              <StatCard label="Pemasukan" value={totalMasuk} icon="📥" color="#34d399" />
              <StatCard label="Pengeluaran" value={totalKeluar} icon="📤" color="#f87171" />
            </div>
            <div style={{ color: "#94a3b8", fontSize: 13, fontWeight: 700, marginBottom: 12, textTransform: "uppercase" }}>Transaksi Terbaru</div>
            {transaksi.slice(0, 5).map(t => <TxRow key={t.id} t={t} />)}
            <div onClick={() => setMenu("transaksi")} style={{ textAlign: "center", padding: 12, color: "#ffd200", fontSize: 14, fontWeight: 600, cursor: "pointer" }}>Lihat semua →</div>
          </>
        )}

        {/* TRANSAKSI */}
        {menu === "transaksi" && (
          <>
            <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
              {["semua", "pemasukan", "pengeluaran"].map(f => (
                <button key={f} onClick={() => setFilter(f)} style={{
                  padding: "8px 14px", borderRadius: 8, border: "1px solid",
                  borderColor: filter === f ? "#ffd200" : "rgba(255,255,255,0.1)",
                  background: filter === f ? "rgba(255,210,0,0.15)" : "transparent",
                  color: filter === f ? "#ffd200" : "#64748b", fontWeight: filter === f ? 700 : 500, fontSize: 13, cursor: "pointer"
                }}>{f === "semua" ? "Semua" : f === "pemasukan" ? "📥 Pemasukan" : "📤 Pengeluaran"}</button>
              ))}
            </div>
            {filtered.length === 0 && <div style={{ textAlign: "center", padding: 40, color: "#475569" }}>Belum ada transaksi</div>}
            {filtered.map(t => <TxRow key={t.id} t={t} />)}
          </>
        )}

        {/* LAPORAN */}
        {menu === "laporan" && (
          <>
            <div style={{ color: "#94a3b8", fontSize: 13, fontWeight: 700, marginBottom: 12, textTransform: "uppercase" }}>Ringkasan Bulan Ini</div>
            <div style={{ display: "flex", gap: 12, marginBottom: 16 }}>
              <StatCard label="Pemasukan" value={totalMasuk} icon="📥" color="#34d399" />
              <StatCard label="Pengeluaran" value={totalKeluar} icon="📤" color="#f87171" />
            </div>
            <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 14, padding: 18, marginBottom: 20 }}>
              <div style={{ color: "#94a3b8", fontSize: 12, fontWeight: 700, marginBottom: 10 }}>KEUNTUNGAN BERSIH</div>
              <div style={{ color: saldo >= 0 ? "#34d399" : "#f87171", fontSize: 28, fontWeight: 900 }}>{formatRupiah(saldo)}</div>
              <div style={{ color: "#475569", fontSize: 12, marginTop: 6 }}>{saldo >= 0 ? "🟢 Usaha Anda menguntungkan!" : "🔴 Pengeluaran melebihi pemasukan"}</div>
            </div>
            <div style={{ color: "#94a3b8", fontSize: 13, fontWeight: 700, marginBottom: 12, textTransform: "uppercase" }}>Pengeluaran per Kategori</div>
            {["Bahan Baku", "Operasional", "Gaji", "Lainnya"].map(kat => {
              const total = transaksi.filter(t => t.jenis === "pengeluaran" && t.kategori === kat).reduce((s, t) => s + t.jumlah, 0);
              if (!total) return null;
              const persen = Math.round((total / totalKeluar) * 100);
              return (
                <div key={kat} style={{ marginBottom: 14 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ color: "#cbd5e1", fontSize: 13 }}>{kat}</span>
                    <span style={{ color: "#f87171", fontSize: 13, fontWeight: 700 }}>{formatRupiah(total)}</span>
                  </div>
                  <div style={{ background: "rgba(255,255,255,0.08)", borderRadius: 4, height: 6 }}>
                    <div style={{ background: "#f87171", width: `${persen}%`, borderRadius: 4, height: 6 }} />
                  </div>
                </div>
              );
            })}
            <div style={{ marginTop: 20, padding: "14px 16px", background: "rgba(255,210,0,0.08)", border: "1px solid rgba(255,210,0,0.2)", borderRadius: 12, color: "#fbbf24", fontSize: 13, textAlign: "center" }}>
              📊 Fitur export PDF & Excel tersedia di versi lengkap
            </div>
          </>
        )}

        {/* PROFIL */}
        {menu === "profil" && (
          <>
            <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 16, padding: 24, marginBottom: 16 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20 }}>
                <div style={{ width: 56, height: 56, borderRadius: 16, background: "linear-gradient(135deg,#f7971e,#ffd200)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24 }}>👤</div>
                <div>
                  <div style={{ color: "#fff", fontWeight: 800, fontSize: 18 }}>{user.nama}</div>
                  <div style={{ color: "#64748b", fontSize: 13 }}>{user.email}</div>
                </div>
              </div>
              {[["Nama Usaha", user.usaha, "🏪"], ["Total Transaksi", `${transaksi.length} transaksi`, "📋"], ["Saldo Saat Ini", formatRupiah(saldo), "💰"]].map(([label, val, icon]) => (
                <div key={label} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                  <span style={{ fontSize: 20 }}>{icon}</span>
                  <div>
                    <div style={{ color: "#64748b", fontSize: 12 }}>{label}</div>
                    <div style={{ color: "#e2e8f0", fontSize: 14, fontWeight: 600 }}>{val}</div>
                  </div>
                </div>
              ))}
            </div>
            <button onClick={() => setUser(null)} style={{ width: "100%", padding: 13, borderRadius: 12, border: "1px solid rgba(239,68,68,0.3)", background: "rgba(239,68,68,0.1)", color: "#ef4444", fontWeight: 700, fontSize: 15, cursor: "pointer" }}>
              🚪 Keluar dari Akun
            </button>
          </>
        )}
      </div>

      {/* MODAL FORM */}
      {showForm && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 100 }}>
          <div style={{ background: "#1e293b", borderRadius: "20px 20px 0 0", padding: "24px 20px 32px", width: "100%", maxWidth: 480, border: "1px solid rgba(255,255,255,0.1)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <h3 style={{ color: "#fff", fontWeight: 800, fontSize: 17, margin: 0 }}>📝 Catat Transaksi Baru</h3>
              <button onClick={() => { setShowForm(false); setFormError(""); }} style={{ background: "rgba(255,255,255,0.1)", border: "none", borderRadius: 8, color: "#fff", fontSize: 18, padding: "4px 10px", cursor: "pointer" }}>✕</button>
            </div>
            <div style={{ marginBottom: 16 }}>
              <label style={{ color: "#94a3b8", fontSize: 12, fontWeight: 700, display: "block", marginBottom: 8 }}>JENIS TRANSAKSI</label>
              <div style={{ display: "flex", gap: 8 }}>
                {["pemasukan", "pengeluaran"].map(j => (
                  <button key={j} onClick={() => setForm({ ...form, jenis: j, kategori: KATEGORI[j][0] })} style={{
                    flex: 1, padding: 10, borderRadius: 10, border: "1px solid",
                    borderColor: form.jenis === j ? (j === "pemasukan" ? "#34d399" : "#f87171") : "rgba(255,255,255,0.1)",
                    background: form.jenis === j ? (j === "pemasukan" ? "rgba(52,211,153,0.15)" : "rgba(248,113,113,0.15)") : "transparent",
                    color: form.jenis === j ? (j === "pemasukan" ? "#34d399" : "#f87171") : "#64748b",
                    fontWeight: 700, fontSize: 14, cursor: "pointer"
                  }}>{j === "pemasukan" ? "📥 Pemasukan" : "📤 Pengeluaran"}</button>
                ))}
              </div>
            </div>
            {[["kategori", "KATEGORI", "select"], ["keterangan", "KETERANGAN", "text"], ["jumlah", "JUMLAH (Rp)", "number"], ["tanggal", "TANGGAL", "date"]].map(([f, label, type]) => (
              <div key={f} style={{ marginBottom: 14 }}>
                <label style={{ color: "#94a3b8", fontSize: 12, fontWeight: 700, display: "block", marginBottom: 8 }}>{label}</label>
                {type === "select" ? (
                  <select value={form[f]} onChange={e => setForm({ ...form, [f]: e.target.value })} style={{ ...inputStyle, background: "#0d1117" }}>
                    {KATEGORI[form.jenis].map(k => <option key={k}>{k}</option>)}
                  </select>
                ) : (
                  <input type={type} value={form[f]} onChange={e => setForm({ ...form, [f]: e.target.value })}
                    placeholder={f === "keterangan" ? "Contoh: Penjualan nasi bungkus" : f === "jumlah" ? "Contoh: 50000" : ""}
                    style={inputStyle} />
                )}
              </div>
            ))}
            {formError && <div style={{ background: "rgba(239,68,68,0.15)", borderRadius: 8, padding: "10px 14px", color: "#fca5a5", fontSize: 13, marginBottom: 14 }}>{formError}</div>}
            <button onClick={tambah} style={{ width: "100%", padding: 14, borderRadius: 12, border: "none", background: "linear-gradient(135deg,#f7971e,#ffd200)", color: "#1a1a1a", fontWeight: 800, fontSize: 16, cursor: "pointer" }}>
              💾 Simpan Transaksi
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
